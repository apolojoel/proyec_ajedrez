
package Jugabilidad;

public class Movimiento {
    private int origenFila;
    private int origenColumna;
    private int destinoFila;
    private int destinoColumna;

    public Movimiento(int origenFila, int origenColumna, int destinoFila, int destinoColumna) {
        this.origenFila = origenFila;
        this.origenColumna = origenColumna;
        this.destinoFila = destinoFila;
        this.destinoColumna = destinoColumna;
    }

    // Métodos getter
    public int getOrigenFila() { return origenFila; }
    public int getOrigenColumna() { return origenColumna; }
    public int getDestinoFila() { return destinoFila; }
    public int getDestinoColumna() { return destinoColumna; }
}
