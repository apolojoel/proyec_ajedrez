package Jugabilidad;

import java.util.HashMap;
import java.util.Map;

public class Tablero {
    private String[][] tablero;
    private Map<String, String> piezas;

    public Tablero() {
        tablero = new String[8][8];
        inicializarTablero();
    }

    private void inicializarTablero() {
        // Coloca las piezas en sus posiciones iniciales
        for (int i = 0; i < 8; i++) {
            tablero[1][i] = "P"; // Peones negros
            tablero[6][i] = "p"; // Peones blancos
        }
        tablero[0][0] = tablero[0][7] = "R"; // Torres negras
        tablero[7][0] = tablero[7][7] = "r"; // Torres blancas
        tablero[0][1] = tablero[0][6] = "N"; // Caballos negros
        tablero[7][1] = tablero[7][6] = "n"; // Caballos blancos
        tablero[0][2] = tablero[0][5] = "B"; // Alfiles negros
        tablero[7][2] = tablero[7][5] = "b"; // Alfiles blancos
        tablero[0][3] = "Q"; tablero[0][4] = "K"; // Reina y Rey negros
        tablero[7][3] = "q"; tablero[7][4] = "k"; // Reina y Rey blancos
    }

    public String[][] getEstadoTablero() {
        return tablero;
    }

    public void actualizarTablero(String movimiento) {
    // Verifica que el movimiento sea suficientemente largo para obtener columna y fila
    if (movimiento.length() >= 2) {
        try {
            int col = movimiento.charAt(0) - 'a'; // Conversión de columna de notación (a-h) a índice (0-7)
            int fila = 8 - Character.getNumericValue(movimiento.charAt(1)); // Conversión de fila de notación (1-8) a índice (7-0)
            
            // Verifica que la fila y columna estén dentro de los límites del tablero
            if (col >= 0 && col < 8 && fila >= 0 && fila < 8) {
                // Aquí se asume que estamos moviendo una pieza, por ejemplo un peón en este caso de prueba
                tablero[fila][col] = "p"; // Este es un ejemplo; deberías actualizar la lógica para cada tipo de movimiento
            }
        } catch (Exception e) {
            System.out.println("Error interpretando el movimiento: " + movimiento);
            e.printStackTrace();
        }
    }
}
}
