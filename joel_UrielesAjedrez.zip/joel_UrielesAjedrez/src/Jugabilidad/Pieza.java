/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Jugabilidad;


public class Pieza {
    private String tipo; // Ejemplo: "Rey", "Reina", "Alfil", etc.
    private String color; // "Blanco" o "Negro"

    public Pieza(String tipo, String color) {
        this.tipo = tipo;
        this.color = color;
    }

    public String getTipo() {
        return tipo;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String toString() {
        return tipo + " (" + color + ")";
    }
}