package Lector;

import java.io.*;
import java.util.ArrayList;

public class LectorPNG {
    private ArrayList<String> movimientos;

    public LectorPNG() {
        movimientos = new ArrayList<>();
    }

    public void leerArchivo(String rutaArchivo) {
        movimientos.clear(); // Limpiar movimientos previos
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                // Ignorar líneas de metadatos entre corchetes
                if (!linea.startsWith("[")) {
                    // Separar movimientos en la línea y agregar a la lista
                    String[] tokens = linea.split("\\s+");
                    for (String token : tokens) {
                        if (token.matches("\\d+\\.")) { // Ignorar números de jugada como "1.", "2."
                            continue;
                        }
                        movimientos.add(token);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    public ArrayList<String> getMovimientos() {
        return movimientos;
    }
}


