package GUI;

import Jugabilidad.Tablero;
import Lector.LectorPNG;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class InterfazGrafica extends JFrame {
    private Tablero tablero;
    private LectorPNG lector;
    private ArrayList<String> movimientos;
    private int indiceMovimiento;
    private JPanel panelTablero;

    public InterfazGrafica() {
        tablero = new Tablero();
        lector = new LectorPNG();
        movimientos = new ArrayList<>();
        indiceMovimiento = 0;
        initUI();
    }

    private void initUI() {
        setTitle("Visor de Partidas de Ajedrez");
        setSize(400, 400);
        setLayout(new BorderLayout());

        panelTablero = new JPanel(new GridLayout(8, 8));
        actualizarTableroVisual();
        add(panelTablero, BorderLayout.CENTER);

        JButton botonCargar = new JButton("Cargar PGN");
        botonCargar.addActionListener(e -> cargarArchivoPGN());
        JButton botonAvanzar = new JButton("Avanzar");
        botonAvanzar.addActionListener(e -> avanzarMovimiento());
        JButton botonRetroceder = new JButton("Retroceder");
        botonRetroceder.addActionListener(e -> retrocederMovimiento());

        JPanel panelControles = new JPanel();
        panelControles.add(botonCargar);
        panelControles.add(botonAvanzar);
        panelControles.add(botonRetroceder);
        add(panelControles, BorderLayout.SOUTH);
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void actualizarTableroVisual() {
        panelTablero.removeAll();
        String[][] estado = tablero.getEstadoTablero();
        for (int fila = 0; fila < 8; fila++) {
            for (int col = 0; col < 8; col++) {
                JButton casilla = new JButton(estado[fila][col] != null ? estado[fila][col] : "");
                casilla.setBackground((fila + col) % 2 == 0 ? Color.WHITE : Color.GRAY);
                panelTablero.add(casilla);
            }
        }
        panelTablero.revalidate();
        panelTablero.repaint();
    }

    private void cargarArchivoPGN() {
        JFileChooser selectorArchivos = new JFileChooser();
        if (selectorArchivos.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            String rutaArchivo = selectorArchivos.getSelectedFile().getAbsolutePath();
            lector.leerArchivo(rutaArchivo);
            movimientos = lector.getMovimientos();
            indiceMovimiento = 0;
            tablero = new Tablero(); // Reinicia el tablero al cargar un nuevo archivo
            actualizarTableroVisual();
        }
    }

    private void avanzarMovimiento() {
        if (indiceMovimiento < movimientos.size()) {
            String movimiento = movimientos.get(indiceMovimiento);
            tablero.actualizarTablero(movimiento);
            indiceMovimiento++;
            actualizarTableroVisual();
        }
    }

    private void retrocederMovimiento() {
        if (indiceMovimiento > 0) {
            indiceMovimiento--;
            tablero = new Tablero(); // Reinicia el tablero
            for (int i = 0; i < indiceMovimiento; i++) {
                tablero.actualizarTablero(movimientos.get(i)); // Reaplica hasta el movimiento actual
            }
            actualizarTableroVisual();
        }
    }
     public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new InterfazGrafica().setVisible(true));
    }
}

